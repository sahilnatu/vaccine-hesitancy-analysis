# -*- coding: utf-8 -*-
"""
Created on Mon Oct  4 11:00:57 2021

@author: sahil
"""

import tweepy
import pandas as pd
import nltk
import numpy as np
import matplotlib as plt
import math
from sklearn.manifold import MDS



keys = pd.read_csv(r'C:\Users\sahil\Google Drive\UT Austin\College\Fall\Unstructured\Project\twitter_keys.csv')
keys.set_index('type',inplace=True)

#auth = tweepy.OAuthHandler(keys.loc['consumer','key'], keys.loc['consumer','secret'])
auth = tweepy.AppAuthHandler(keys.loc['consumer','key'], keys.loc['consumer','secret'])
#auth.set_access_token(keys.loc['access','key'], keys.loc['access','secret'])

api = tweepy.API(auth, wait_on_rate_limit=True)

result_df = pd.DataFrame(columns=('user_id','user','tweet_id','text','location','date'))
followed_users_list = []
total = 60094
max_id=1442964249609846785
while total<100000:
    if total==0:
        for tweet in api.search_tweets(q=["vaccine covid"], lang="en", count=100, geocode="40.0902,-95.7129,2500km"):
            place = None
            if tweet.place!=None:
                place = str(tweet.place).split("', ")[4].split("='")[1]
            result_df = result_df.append(pd.DataFrame([[tweet.user.id, tweet.user.screen_name, tweet.id, tweet.text, place, tweet.created_at]],columns=('user_id','user','tweet_id','text','location','date')),ignore_index=True)
            total = total+1
            print(total)
        max_id = result_df.iloc[-1,2]
    else:
        for tweet in api.search_tweets(q=["vaccine covid"], lang="en", max_id=max_id, count=100, geocode="40.0902,-95.7129,2500km"):
            place = None
            if tweet.place!=None:
                place = str(tweet.place).split("', ")[4].split("='")[1]
            result_df = result_df.append(pd.DataFrame([[tweet.user.id, tweet.user.screen_name, tweet.id, tweet.text, place, tweet.created_at]],columns=('user_id','user','tweet_id','text','location','date')),ignore_index=True)
            total = total+1
            print(total)
        max_id = result_df.iloc[-1,2]
            
result_df.to_csv(r'C:\Users\sahil\Google Drive\UT Austin\College\Fall\Unstructured\Project\tweets4.csv', index = False, header=True)
